def say_hello(): 
    print("hello world")

def say_hello2(text):
    print("Hola {text}")